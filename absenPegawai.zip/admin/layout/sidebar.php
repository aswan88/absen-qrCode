<aside class="left-sidebar" data-sidebarbg="skin5">
        <!-- Sidebar scroll-->
        <div class="scroll-sidebar">
          <!-- Sidebar navigation-->
          <nav class="sidebar-nav">
            <ul id="sidebarnav" class="pt-4">
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="index.php"
                  aria-expanded="false"
                  ><i class="mdi mdi-view-dashboard"></i
                  ><span class="hide-menu">Dashboard</span></a
                >
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="pegawai.php"
                  aria-expanded="false"
                  ><i class="mdi mdi-account-card-details"></i
                  ><span class="hide-menu">Data Pegawai</span></a
                >
              </li>
              <li class="sidebar-item">
                <a
                  class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="absen.php"
                  aria-expanded="false"
                  ><i class="mdi mdi-account-check"></i
                  ><span class="hide-menu">Absen</span></a
                >
              </li>
              <li class="sidebar-item">
                <a class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="admin.php"
                  aria-expanded="false"
                  ><i class="mdi mdi-account-star"></i
                  ><span class="hide-menu">Admin</span></a
                >
              </li>
              <li class="sidebar-item">
                <a class="sidebar-link waves-effect waves-dark sidebar-link"
                  href="../logout.php"
                  aria-expanded="false"
                  ><i class="fa fa-power-off me-1 ms-1"></i><span class="hide-menu">Logout</span></a
                >
              </li>
            </ul>
          </nav>
          <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
      </aside>